<div class='row'>
    <div class='col-md-12'>
        <div class='panel panel-default'>
            <div class='panel-heading'>
                <h3 class='panel-title'><?php echo $titre ;?> </h3>
            </div>
            <div class='panel-body'>
<br>
<br>
<center>
<?php echo "<h1>". $message."<h1>";?>
</center>
<br>
<br>
</div>
        </div>
    </div>

</div> <!-- End Row -->