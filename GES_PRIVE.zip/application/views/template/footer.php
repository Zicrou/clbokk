
<script>
    var resizefunc = [];
</script>

<!-- Main  -->
<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/detect.js"></script>
<script src="<?php echo base_url(); ?>assets/js/fastclick.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.blockUI.js"></script>
<script src="<?php echo base_url(); ?>assets/js/waves.js"></script>
<script src="<?php echo base_url(); ?>assets/js/wow.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.nicescroll.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/gpes_script.js"></script>

<script src="<?php echo base_url(); ?>assets/js/jquery.app.js"></script>

<!-- jQuery  -->
<script src="<?php echo base_url(); ?>assets/plugins/moment/moment.js"></script>

<script src="<?php echo base_url(); ?>assets/js/managing_menu.js"></script>
<script src="<?php echo base_url(); ?>assets/js/managing_ajax.js"></script>

<!-- sweetalert  -->
<link href="<?php echo base_url(); ?>assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url(); ?>assets/plugins/sweetalert/dist/sweetalert.min.js"></script>


<!-- Modal Plugins css
<link href="<php echo base_url(); ?>assets/plugins/modal-effect/css/component.css" rel="stylesheet">-->


<!-- DataTables js && css -->
<link href="<?php echo base_url(); ?>assets/plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/plugins/jquery-datatable/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>


<!--Form Validation
<script src="<php echo base_url(); ?>assets/plugins/bootstrapvalidator/dist/js/bootstrapValidator.js" type="text/javascript"></script>-->

<!--Form Wizard-->
<script src="<?php echo base_url(); ?>assets/plugins/jquery.steps/build/jquery.steps.min.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery-validation/dist/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin-forms/js/jquery.validate.translations.fr-FR.js"></script>-->

<!-- jQuery Validate Plugin && Admin Forms CSS
<link rel="stylesheet" type="text/css" href="?php echo base_url(); ?>assets/admin-forms/css/admin-forms.css">
<script src="?php echo base_url(); ?>assets/admin-forms/js/jquery.validate.min.js"></script>->

<!-- inputmask js
<script src="<php echo base_url(); ?>assets/plugins/bootstrap-inputmask/bootstrap-inputmask.min.js" type="text/javascript"></script>-->

<!--Select js
<link href="<php echo base_url(); ?>assets/plugins/select2/dist/css/select2.css" rel="stylesheet" type="text/css">
<link href="<php echo base_url(); ?>assets/plugins/select2/dist/css/select2-bootstrap.css" rel="stylesheet" type="text/css">
<script src="<php echo base_url(); ?>assets/plugins/select2/dist/js/select2.min.js" type="text/javascript"></script>->

<!--datepicker js
<link href="<php echo base_url(); ?>assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
<script type="text/javascript" src="<php echo base_url(); ?>assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<php echo base_url(); ?>assets/plugins/bootstrap-datepicker/dist/locales/bootstrap-datepicker.fr.min.js"></script>->

<!-- notification js-->
<link href="<?php echo base_url(); ?>assets/plugins/notifications/notification.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>assets/plugins/notifyjs/dist/notify.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/notifications/notify-metro.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/notifications/notifications.js"></script>

<link href="<?php echo base_url(); ?>assets/plugins/jquery-multi-select/multi-select.css" rel="stylesheet" type="text/css">
<style type="text/css">.ms-container {  width: 100%; }
    .ms-container .ms-selectable li.ms-hover, .ms-container .ms-selection li.ms-hover {  background-color: #33b86c; }
</style>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery-multi-select/jquery.multi-select.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/jquery-multi-select/jquery.quicksearch.js"></script>




</body>
</html>

