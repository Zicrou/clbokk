<!-- Right Sidebar -->
<!--
            <div class="side-bar right-bar nicescroll">
                <h4 class="text-center">Annee scolaire</h4>
                <div class="contact-list nicescroll my_widget ">
                    <form method="post">
                        <?php
                       /*  if($this->session->ans != $this->session->ans_cur)
                        {
                            ?>
                            <label style="margin-left:10px; cursor: Pointer; color:#09F">
								<input name="annee_select" value="<?php echo $this->session->ans_cur."bks".$this->session->lans_cur; ?>" type="radio" onchange="this.form.submit();"/>
                                <span> <?php echo $this->session->lans_cur; ?></span>
							</label>
                            <br>
                            <?php
                        } */
						
                        /* foreach($an_archiv as $an)
                        {
                            ?>
                            
                            <label style="margin-left:10px; cursor: Pointer;">
								<input name="annee_select" value="<?php echo $an->annee_cours."bks".$an->libelle_annee; ?>" type="radio" onchange="this.form.submit();"/>
                                <span> <?php echo $an->libelle_annee; ?></span>
							</label>
                            <br>
                            <?php
                        } */
                        ?>
                     </form>
                </div>
            </div>-->
            <!-- /Right-bar -->