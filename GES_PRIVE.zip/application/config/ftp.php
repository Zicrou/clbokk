<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$ftp['default'] = array(
	'hostname' => '196.207.144.5',
	'username' => 'Administrateur',
	'password' => 'Son@tel221',
	'port' => '21'
);
